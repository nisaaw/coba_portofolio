# Annisa — Chemical Analysis Portfolio

A complete responsive personal portfolio built with Streamlit.

## Features

- Premium minimalist UI
- Responsive desktop/mobile layout
- Sticky navigation
- Hero section
- About section
- Experience timeline
- Skills with progress bars
- Interactive project selector
- Project cards
- Certifications
- Contact form UI
- Mobile-friendly CSS
- No external database required

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## GitHub + Streamlit Cloud

1. Create a GitHub repository.
2. Upload `app.py` and `requirements.txt`.
3. Open Streamlit Community Cloud.
4. Select the repository.
5. Main file: `app.py`.
6. Deploy.

## Personalize

At the top of `app.py`, edit:

- `PROFILE`
- `EXPERIENCE`
- `SKILLS`
- `PROJECTS`
- `CERTIFICATIONS`

Replace placeholder contact information before publishing.

## Add a real CV

You can later put your PDF inside `assets/` and add a Streamlit download button.

## Notes

The percentages in Skills are presentation values, not formal competency measurements. Adjust them or replace the progress bars with neutral skill categories if preferred.
